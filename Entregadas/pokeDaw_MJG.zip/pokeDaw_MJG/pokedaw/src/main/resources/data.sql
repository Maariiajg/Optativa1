INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (1, 'Bulbasaur', 'PLANTA', 'VENENO', '2025-01-15', 'POKEBALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (4, 'Charmander', 'FUEGO', 'NINGUNO', '2025-02-10', 'SUPERBALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (7, 'Squirtle', 'AGUA', 'NINGUNO', '2025-03-05', 'ULTRABALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (10, 'Caterpie', 'BICHO', 'NINGUNO', '2025-01-20', 'POKEBALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (16, 'Pidgey', 'NORMAL', 'VOLADOR', '2025-04-01', 'SUPERBALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (25, 'Pikachu', 'ELECTRICO', 'NINGUNO', '2025-05-05', 'ULTRABALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (39, 'Jigglypuff', 'NORMAL', 'PSIQUICO', '2025-06-10', 'POKEBALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (66, 'Machop', 'LUCHA', 'NINGUNO', '2025-07-15', 'SUPERBALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (92, 'Gastly', 'FANTASMA', 'VENENO', '2025-08-25', 'POKEBALL');

INSERT INTO pokemon (numero_pokedex, titulo, tipo1, tipo2, fecha_captura, capturado)
VALUES (131, 'Lapras', 'AGUA', 'HIELO', '2025-09-12', 'ULTRABALL');
