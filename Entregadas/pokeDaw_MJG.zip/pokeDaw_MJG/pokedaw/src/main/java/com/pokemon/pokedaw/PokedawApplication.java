package com.pokemon.pokedaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokedawApplication {

	public static void main(String[] args) {
		SpringApplication.run(PokedawApplication.class, args);
	}

}
