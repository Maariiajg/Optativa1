package com.pokemon.pokedaw.persistence.entities.enums;

public enum Tipo {
	NINGUNO, BICHO, DRAGON, ELECTRICO, LUCHA, FUEGO, VOLADOR, FANTASMA, PLANTA, TIERRA, HIELO, NORMAL, VENENO, PSIQUICO, ROCA, AGUA
}
