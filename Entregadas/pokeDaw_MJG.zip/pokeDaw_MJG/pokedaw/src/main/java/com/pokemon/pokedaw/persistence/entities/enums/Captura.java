package com.pokemon.pokedaw.persistence.entities.enums;

public enum Captura {
	POKEBALL, SUPERBALL, ULTRABALL
}
