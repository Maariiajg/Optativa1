package com.daw.services.exceptions;

public class TareaException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8954845870461706054L;

	public TareaException(String message) {
		super(message);
	}

}