package com.daw.persistence.entities.enums;

public enum Estado {
	
	PENDIENTE, EN_PROCESO, COMPLETADA

}