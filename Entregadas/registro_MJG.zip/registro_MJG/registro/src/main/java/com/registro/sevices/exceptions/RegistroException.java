package com.registro.sevices.exceptions;

public class RegistroException extends RuntimeException {
	private static final long serialVersionUID = 8954845870461706054L;

	public RegistroException(String message) {
		super(message);
	}
}