package com.registro.persistences.entities.enums;

public enum Unidad {
	CELSIUS, FAHRENHEIT
}
