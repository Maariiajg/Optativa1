INSERT INTO registro (fecha_lectura, ubicacion, temperatura, unidad, precipitacion) VALUES
('2025-01-10', 'Madrid', 15.2, 'CELSIUS', 0.0),
('2025-01-11', 'Barcelona', 18.5, 'CELSIUS', 1.2),
('2025-01-12', 'Sevilla', 22.0, 'CELSIUS', 0.0),
('2025-01-13', 'Valencia', 19.3, 'CELSIUS', 0.5),
('2025-01-14', 'Bilbao', 10.7, 'CELSIUS', 4.1),
('2025-01-15', 'New York', 68.0, 'FAHRENHEIT', 0.8),
('2025-01-16', 'Los Angeles', 72.5, 'FAHRENHEIT', 0.0),
('2025-01-17', 'Chicago', 45.2, 'FAHRENHEIT', 2.3),
('2025-01-18', 'Houston', 80.1, 'FAHRENHEIT', 0.0),
('2025-01-19', 'Miami', 85.3, 'FAHRENHEIT', 3.7);

